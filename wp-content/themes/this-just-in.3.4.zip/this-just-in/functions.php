<?php
if(function_exists('register_sidebar'))
	register_sidebar(array (
		'before_widget' => '<li>',
		'after_widget' => '</li>',
		'before_title' => '<span class="sidetitle">',
		'after_title' => '</span>',
	));
	
// Call comments based on existence of wp_list_comments function
add_filter('comments_template', 'legacy_comments');

function legacy_comments($file) {

	if(!function_exists('wp_list_comments')) : // WP 2.7-only check
		$file = TEMPLATEPATH . '/legacy.comments.php';
	endif;
	
	return $file;
}

// filter tag clould output so that it can be styled by CSS
// courtesy of http://www.c0defeed.com/2008/09/30/howto-use-css-to-style-the-wordpress-tag-cloud-widget/
function style_tag_cloud($tags) {
    $tags = preg_replace_callback("|(class='tag-link-[0-9]+)('.*?)(style='font-size: )([0-9]+)(pt;')|",
        create_function(
            '$match',
            '$low=1; $high=5; $sz=($match[4]-8.0)/(22-8)*($high-$low)+$low; return "{$match[1]} tji_tag {$match[2]}";'
        ),
        $tags);
    return $tags;
}
 
// Hook into the rendering of the tag cloud widget
add_action('wp_tag_cloud', 'style_tag_cloud');
?>
