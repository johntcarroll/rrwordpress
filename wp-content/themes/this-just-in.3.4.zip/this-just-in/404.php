<?php include(TEMPLATEPATH . '/header_plain.php'); ?>

	<div id="content">

		<div <?php post_class(); ?>>
		<h1 class="attr">Page Not Found</h1>
			<div class="fourohfour">
				<p>The page you requested could not be found. No worries, try one of these options to find what you're looking for &darr;</p>
				<ol>
				<li><a href="<?php bloginfo('url'); ?>" title="Go to the homepage">&larr; Start at the home page</a></li>
				<li><a href="<?php bloginfo('url'); ?>/archives/" title="Browse the archives">&larr; Browse the archives</a></li>
				<li>Search the site:
				<?php include(TEMPLATEPATH . '/searchform.php'); ?></li>
				</ol>
			</div>
		</div>

	</div>

<?php get_footer(); ?>