<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<div><input type="text" name="s" id="s" onblur="searchblur(this);" onfocus="searchfocus(this);" value="To search, type and hit enter..." />
<input type="hidden" id="searchsubmit" value="Search" />
</div>
</form>