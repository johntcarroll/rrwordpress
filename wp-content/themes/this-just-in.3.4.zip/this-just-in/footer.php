<div class="clearfloatthick"></div>
<div id="footer">
	<p>
		Powered by <a href="http://www.wordpress.org" title="Powered by WordPress">WordPress</a>
		| &copy; <?php echo date('Y'); ?> <a href="<?php bloginfo('url'); ?>" title="Copywrite <?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>
		| <span class="credits">Theme by <a href="http://wphackr.com" title="Visit WPHackr">WPHackr.com</a></span>
	</p>
</div>
</div>

<!--This is another plugin hook-->
<?php wp_footer(); ?>

</body>
</html>
